module com.fazecast.jSerialComm {
	exports com.fazecast.jSerialComm;
}